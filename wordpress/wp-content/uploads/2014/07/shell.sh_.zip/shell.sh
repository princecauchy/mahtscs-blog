#!/bin/bash
from="/home/cauchy/桌面/shell_script";
to="/home/cauchy/桌面/shell_script";
cd ${from}
dirnames=$(ls -d [2-9][0-9][0-9][0-9]*)
for dir in ${dirnames}; do 
    cd ${dir}
    filenames=$(ls)
    for file in ${filenames}; do 
        if [ -f "$file" ]; then
            pattern=${file:0:2}
            [ -r ${to}/${pattern}* ] && { cp -f ${file} ${to}/${pattern}*; }
        else
            echo ${file}"失败的文件"
        fi
    done
    cd ${from}
done
